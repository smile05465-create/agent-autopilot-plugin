# Agent Autopilot Plugin — expanded starter

MCP stdio server provides scoped workspace file tools, public web search, and read-only GitHub research.

## Tools
Workspace: `workspace_list_files`, `workspace_read_file`, `workspace_search_files`, `workspace_write_file`.
Web: `web_search` (DuckDuckGo HTML; network required; parser may need updates if markup changes).
GitHub: `github_search_repositories`, `github_read_file`, `github_list_open_issues` (public API; optional `GITHUB_TOKEN` for higher limits/private repos).

## Configure an MCP-capable host
`.mcp.json` remains empty because local paths depend on your machine. Configure the host with:

```json
{
  "mcpServers": {
    "agent-autopilot": {
      "command": "python3",
      "args": ["/ABSOLUTE/PATH/TO/agent-autopilot-plugin/scripts/mcp_server.py"],
      "env": {"AGENT_WORKSPACE": "/ABSOLUTE/PATH/TO/YOUR/PROJECT"}
    }
  }
}
```
Replace both paths. Store `GITHUB_TOKEN` only in host secret/environment settings, never in code or chat.

## Limits/status
No shell execution, GitHub writes/commits, issue creation, deployment, phone control, or background tasks. Code was added but not launched in an MCP host or network-tested. Host compatibility and search parsing remain unverified.
