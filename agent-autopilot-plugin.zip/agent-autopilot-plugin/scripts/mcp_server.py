#!/usr/bin/env python3
"""Minimal stdlib MCP stdio server for safe text-file workspace operations.

Configure AGENT_WORKSPACE to the project directory the agent may access.
This server intentionally does not expose shell execution, arbitrary network access,
or delete/move operations.
"""
import json
import os
import sys
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from pathlib import Path

PROTOCOL_VERSION = "2024-11-05"
ROOT = Path(os.environ.get("AGENT_WORKSPACE", ".")).expanduser().resolve()

def safe_path(rel):
    if not isinstance(rel, str) or not rel.strip():
        raise ValueError("A non-empty relative path is required.")
    candidate = (ROOT / rel).resolve()
    if candidate != ROOT and ROOT not in candidate.parents:
        raise ValueError("Path is outside the configured workspace.")
    return candidate

def text_result(text):
    return {"content": [{"type": "text", "text": str(text)}]}

def list_files(args):
    rel = args.get("path", ".")
    folder = safe_path(rel)
    if not folder.exists() or not folder.is_dir():
        raise ValueError("Folder does not exist.")
    entries = []
    for p in sorted(folder.iterdir(), key=lambda x: x.name.lower()):
        entries.append(("DIR " if p.is_dir() else "FILE ") + p.name)
    return text_result("\n".join(entries) if entries else "(empty folder)")

def read_file(args):
    p = safe_path(args.get("path"))
    if not p.is_file():
        raise ValueError("File does not exist.")
    if p.stat().st_size > 1_000_000:
        raise ValueError("File exceeds 1 MB limit.")
    try:
        return text_result(p.read_text(encoding="utf-8"))
    except UnicodeDecodeError:
        raise ValueError("File is not UTF-8 text.")

def search_files(args):
    query = args.get("query")
    if not isinstance(query, str) or not query:
        raise ValueError("query must be a non-empty string.")
    base = safe_path(args.get("path", "."))
    if not base.is_dir():
        raise ValueError("Search path must be a folder.")
    hits, scanned = [], 0
    for p in base.rglob("*"):
        if not p.is_file() or any(part.startswith(".") for part in p.relative_to(ROOT).parts):
            continue
        if p.suffix.lower() not in {".txt", ".md", ".json", ".js", ".jsx", ".ts", ".tsx", ".py", ".html", ".css", ".yml", ".yaml"}:
            continue
        scanned += 1
        if scanned > 2000:
            break
        try:
            lines = p.read_text(encoding="utf-8").splitlines()
        except (UnicodeDecodeError, OSError):
            continue
        for i, line in enumerate(lines, 1):
            if query.casefold() in line.casefold():
                hits.append(f"{p.relative_to(ROOT)}:{i}: {line[:300]}")
                if len(hits) >= 100:
                    return text_result("\n".join(hits))
    return text_result("\n".join(hits) if hits else "No matches found.")

def write_file(args):
    rel, content = args.get("path"), args.get("content")
    if not isinstance(content, str):
        raise ValueError("content must be text.")
    p = safe_path(rel)
    if len(content.encode("utf-8")) > 1_000_000:
        raise ValueError("Content exceeds 1 MB limit.")
    if p.exists() and not p.is_file():
        raise ValueError("Target exists and is not a file.")
    p.parent.mkdir(parents=True, exist_ok=True)
    # Explicit write tool; host/user must authorize its use.
    p.write_text(content, encoding="utf-8")
    return text_result(f"Wrote {p.relative_to(ROOT)} ({len(content)} characters).")


def web_search(args):
    query=args.get("query")
    if not isinstance(query,str) or not query.strip(): raise ValueError("query required")
    url="https://html.duckduckgo.com/html/?q="+urllib.parse.quote_plus(query.strip())
    req=urllib.request.Request(url,headers={"User-Agent":"AgentAutopilotMCP/0.1","Accept":"text/html"})
    with urllib.request.urlopen(req,timeout=15) as resp: html=resp.read(1500000).decode("utf-8",errors="replace")
    class P(HTMLParser):
        def __init__(self): super().__init__(); self.rows=[]; self.href=None; self.mode=None; self.buf=[]; self.title=""
        def handle_starttag(self,tag,attrs):
            a=dict(attrs); cls=a.get("class","")
            if tag=="a" and "result__a" in cls: self.href=a.get("href",""); self.mode="title"; self.buf=[]
            elif self.href and "result__snippet" in cls: self.mode="snippet"; self.buf=[]
        def handle_data(self,data):
            if self.mode: self.buf.append(data)
        def handle_endtag(self,tag):
            if self.mode=="title" and tag=="a": self.title=" ".join("".join(self.buf).split()); self.mode=None; self.buf=[]
            elif self.mode=="snippet" and tag in ("a","div"):
                self.rows.append((self.title,self.href," ".join("".join(self.buf).split())))
                self.href=None; self.mode=None; self.buf=[]
    p=P(); p.feed(html)
    rows=p.rows[:8]
    return text_result("\n".join(f"{i}. {t}\n   {u}\n   {s}" for i,(t,u,s) in enumerate(rows,1)) if rows else "No parsable results; try native host web search.")

def github_api(path):
    h={"User-Agent":"AgentAutopilotMCP/0.1","Accept":"application/vnd.github+json"}
    tok=os.environ.get("GITHUB_TOKEN")
    if tok: h["Authorization"]="Bearer "+tok
    req=urllib.request.Request("https://api.github.com"+path,headers=h)
    with urllib.request.urlopen(req,timeout=15) as r: return json.loads(r.read(2000000).decode("utf-8"))

def github_search_repositories(args):
    q=args.get("query")
    if not isinstance(q,str) or not q.strip(): raise ValueError("query required")
    data=github_api("/search/repositories?q="+urllib.parse.quote(q.strip())+"&per_page=5")
    return text_result("\n".join(f"{i}. {x.get('full_name')} — {x.get('description') or 'No description'}\n   {x.get('html_url')} | stars {x.get('stargazers_count')}" for i,x in enumerate(data.get("items",[]),1)) or "No repositories found.")

def github_read_file(args):
    owner,repo,path=(args.get(k) for k in ("owner","repo","path"))
    if not all(isinstance(v,str) and v.strip() for v in (owner,repo,path)): raise ValueError("owner, repo, path required")
    data=github_api(f"/repos/{urllib.parse.quote(owner)}/{urllib.parse.quote(repo)}/contents/{urllib.parse.quote(path,safe='/')}")
    if isinstance(data,list): return text_result("Path is a directory; request a specific file.")
    if data.get("type")!="file" or not data.get("content"): raise ValueError("Not a readable inline text file.")
    import base64
    content=base64.b64decode(data["content"]).decode("utf-8",errors="replace")
    return text_result(f"{owner}/{repo}/{path}\n"+content[:50000]+("\n[truncated]" if len(content)>50000 else ""))

def github_list_issues(args):
    owner,repo=args.get("owner"),args.get("repo")
    if not all(isinstance(v,str) and v.strip() for v in (owner,repo)): raise ValueError("owner, repo required")
    items=github_api(f"/repos/{urllib.parse.quote(owner)}/{urllib.parse.quote(repo)}/issues?state=open&per_page=10")
    issues=[x for x in items if "pull_request" not in x]
    return text_result("\n".join(f"#{x['number']} {x['title']}\n  {x['html_url']}" for x in issues) or "No open issues.")

TOOLS = [
    {"name":"workspace_list_files","description":"List files and folders in the configured workspace directory.","inputSchema":{"type":"object","properties":{"path":{"type":"string","description":"Relative folder path; defaults to workspace root."}}}},
    {"name":"workspace_read_file","description":"Read a UTF-8 text file (up to 1 MB) inside the configured workspace.","inputSchema":{"type":"object","properties":{"path":{"type":"string","description":"Relative file path."}},"required":["path"]}},
    {"name":"workspace_search_files","description":"Search text in common source/document files in the workspace.","inputSchema":{"type":"object","properties":{"query":{"type":"string"},"path":{"type":"string","description":"Relative folder path; defaults to workspace root."}},"required":["query"]}},
    {"name":"workspace_write_file","description":"Create or replace a UTF-8 text file inside the workspace. Ask the user before overwriting important files.","inputSchema":{"type":"object","properties":{"path":{"type":"string"},"content":{"type":"string"}},"required":["path","content"]}},
    {"name":"web_search","description":"Search public web with DuckDuckGo HTML; requires network.","inputSchema":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
    {"name":"github_search_repositories","description":"Search GitHub repositories; optional GITHUB_TOKEN for rate limits/private access.","inputSchema":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
    {"name":"github_read_file","description":"Read a repository text file via GitHub Contents API.","inputSchema":{"type":"object","properties":{"owner":{"type":"string"},"repo":{"type":"string"},"path":{"type":"string"}},"required":["owner","repo","path"]}},
    {"name":"github_list_open_issues","description":"List up to 10 open issues in a GitHub repo.","inputSchema":{"type":"object","properties":{"owner":{"type":"string"},"repo":{"type":"string"}},"required":["owner","repo"]}}
]

def handle(msg):
    method = msg.get("method")
    rid = msg.get("id")
    params = msg.get("params") or {}
    if method == "initialize":
        return {"jsonrpc":"2.0","id":rid,"result":{"protocolVersion":PROTOCOL_VERSION,"capabilities":{"tools":{}},"serverInfo":{"name":"agent-autopilot-workspace","version":"0.1.0"}}}
    if method == "notifications/initialized":
        return None
    if method == "ping":
        return {"jsonrpc":"2.0","id":rid,"result":{}}
    if method == "tools/list":
        return {"jsonrpc":"2.0","id":rid,"result":{"tools":TOOLS}}
    if method == "tools/call":
        name = params.get("name")
        args = params.get("arguments") or {}
        try:
            if name == "workspace_list_files": result = list_files(args)
            elif name == "workspace_read_file": result = read_file(args)
            elif name == "workspace_search_files": result = search_files(args)
            elif name == "workspace_write_file": result = write_file(args)
            elif name == "web_search": result = web_search(args)
            elif name == "github_search_repositories": result = github_search_repositories(args)
            elif name == "github_read_file": result = github_read_file(args)
            elif name == "github_list_open_issues": result = github_list_issues(args)
            else: raise ValueError("Unknown tool.")
            return {"jsonrpc":"2.0","id":rid,"result":result}
        except Exception as e:
            return {"jsonrpc":"2.0","id":rid,"result":{"isError":True,"content":[{"type":"text","text":str(e)}]}}
    if rid is not None:
        return {"jsonrpc":"2.0","id":rid,"error":{"code":-32601,"message":"Method not found"}}
    return None

def main():
    for line in sys.stdin:
        try:
            msg = json.loads(line)
            response = handle(msg)
            if response is not None:
                sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
                sys.stdout.flush()
        except Exception as e:
            sys.stdout.write(json.dumps({"jsonrpc":"2.0","id":None,"error":{"code":-32700,"message":str(e)}}) + "\n")
            sys.stdout.flush()

if __name__ == "__main__":
    main()
