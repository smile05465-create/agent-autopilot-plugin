No hooks are enabled in this starter. Add event hooks only after defining a concrete, safe use case and validating host support.
